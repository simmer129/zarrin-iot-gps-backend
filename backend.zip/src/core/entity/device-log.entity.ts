import { Device } from './device.entity';

export class DeviceLog {
  id: string;
  lat: number;
  lon: number;
  createAt: Date;
  device: Device;
}
