export class Account {
  id: string;
  title: string;
}
