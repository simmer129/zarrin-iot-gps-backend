import { Module } from '@nestjs/common';
import { UserService } from './user.service';
import { UserController } from './user.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserSchema } from '../core/schemas/user.schema';
import { AuthModule } from './auth/auth.module';
import { User } from '@/core/entity/user.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      UserSchema
    ]),
    AuthModule
  ],
  providers: [UserService],
  controllers: [UserController],
  exports: [TypeOrmModule]
})
export class UserModule {}
