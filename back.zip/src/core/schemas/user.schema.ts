import { EntitySchema } from 'typeorm';
import { GenderType } from '../entity/gender-type.enum';
import { UserRole } from '../entity/user-role.enum';
import { User } from '../entity/user.entity';

export const UserSchema = new EntitySchema<User>({
  name: 'User',
  target: User,
  columns: {
    id: {
      type: 'uuid',
      primary: true,
      generated: 'uuid',
    },
    userName: {
      type: String,
      nullable: true,
    },
    password: {
      type: String,
      nullable: true,
    },
    mobile: {
      type: Number,
      nullable: true,
      default: 0,
    },
    email: {
      type: String,
      nullable: true,
      default: 'email',
    },
    gender: {
      type: 'enum',
      enum: GenderType,
      nullable: true,
    },
    avatar: {
      type: String,
      nullable: true
    },
    firstName: {
      type: String,
      nullable: true,
    },
    lastName: {
      type: String,
      nullable: true,
    },
    birthDate: {
      type: String,
      nullable: true,
    },
    role: {
      type: 'enum',
      enum: UserRole,
      nullable: true,
    },
    instagram: {
      type: String,
      nullable: true,
    },
    phoneNumber: {
      type: 'double precision',
      nullable: true,
    },
    address: {
      type: String,
      nullable: true,
    },
    createdAt: {
      type: Date,
      createDate: true,
    },
    lastLoginAt: {
      type: Date,
      nullable: true,
    },
  },
  relations: {
    device: {
      type: 'one-to-many',
      target: 'Device',
      nullable: true,
    },
  },
});
