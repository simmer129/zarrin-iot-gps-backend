export enum UserRole {
    Admin,
    Business,
    Staff,
}