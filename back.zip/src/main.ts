import { ValidationPipe } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { NestFactory } from '@nestjs/core';
import { NestExpressApplication } from '@nestjs/platform-express';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { AppModule } from './app.module';

async function bootstrap() {
  const app: NestExpressApplication = await NestFactory.create(AppModule, {
    logger: ['error', 'log', 'verbose'],
  });
  const config: ConfigService = app.get(ConfigService);

  const configDocumentBuilder = new DocumentBuilder()
    .setTitle('GPS IOT')
    .setVersion('0.1')
    .build();

  const document = SwaggerModule.createDocument(app, configDocumentBuilder, {
    deepScanRoutes: true,
    include: [AppModule],
  });

  SwaggerModule.setup('swagger', app, document);

  const port: number = config.get<number>('PORT');

  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));

  await app.listen(port, () => {
    console.log('[WEB]', `http://localhost:${port}`);
  });
}
bootstrap();
